// This file stores bug reports
export const bugReports = [
  // Format:
  // {
  //   id: number,
  //   date: string,
  //   comment: string
  // }
]; 