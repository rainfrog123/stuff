// ==UserScript==
// @name         Betting Handler with Split Bet Logic
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Receives betting signal, splits the bet amount into chunks, and clicks the appropriate Player or Banker button
// @author       You
// @match        *://client.pragmaticplaylive.net/desktop/baccaratgame/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    console.log("Betting Handler Script Initialized: Listening for ResultDetected event...");

    // Function to simulate a click on a DOM element
    function simulateClick(element) {
        if (element) {
            element.click();
        } else {
            console.warn("Element not found!");
        }
    }

    // Function to get the Player button
    function getPlayerButton() {
        return document.querySelector(
            '#scalable > div.dndBetBoardInternal.css-f4qhou.e1xfj7d90 > div.betboard_desktop_wrapper.dndBetBoard.droppable-cancel.global_bb_shadow > div.dndBetPosition.betCode.css-rfx7an.ei0gduo0 > div.PLAYER_PATH.css-10sa813.ei0gduo3 > div.betspotAsset'
        );
    }

    // Function to get the Banker button
    function getBankerButton() {
        return document.querySelector(
            '#scalable > div.dndBetBoardInternal.css-f4qhou.e1xfj7d90 > div.betboard_desktop_wrapper.dndBetBoard.droppable-cancel.global_bb_shadow > div.dndBetPosition.betCode.css-1bbmcr7.ei0gduo0 > div.BANKER_PATH.css-1otckat.ei0gduo3 > div.betspotAsset'
        );
    }

    // Function to get chips
    function getChipElement(chipValue) {
        if (chipValue === 0.2) {
            return document.querySelector("#scalable > div.css-1fee25s.e1vfy7cn1 > div.css-1t0bgiz.e1vfy7cn0 > span.css-1vi1rg2.e1jwh40g14"); // Chip 0.2
        } else if (chipValue === 1) {
            return document.querySelector("#scalable > div.css-1fee25s.e1vfy7cn1 > div.css-1t0bgiz.e1vfy7cn0 > span:nth-child(2)"); // Chip 1
        } else if (chipValue === 5) {
            return document.querySelector("#scalable > div.css-1fee25s.e1vfy7cn1 > div.css-1t0bgiz.e1vfy7cn0 > span:nth-child(3)"); // Chip 5
        }
        return null;
    }

    // Function to get the balance
    function getBalance() {
        const balanceElement = document.querySelector(
            '#scalable > div.css-0.e1mid7uy0 > div > div.balanceContainer > div.balance > div.amt'
        );
        if (balanceElement) {
            const balanceText = balanceElement.textContent.replace('$', '').trim();
            return Math.floor(parseFloat(balanceText)); // Parse the balance as a float and round down
        }
        console.warn("Unable to retrieve balance!");
        return 0;
    }

    // Function to split the bet amount into chunks
    function splitBetAmount(amount) {
        const chips = [5, 1, 0.2]; // Available chip values in descending order
        const chunks = [];

        for (const chip of chips) {
            while (amount >= chip) {
                chunks.push(chip);
                amount -= chip;
            }
        }

        return chunks;
    }

    // Function to place the bet in chunks
    function placeBet(chunks, targetButton) {
        chunks.forEach((chipValue) => {
            const chipElement = getChipElement(chipValue);
            if (chipElement) {
                simulateClick(chipElement); // Select the chip
                simulateClick(targetButton); // Place the bet with the selected chip
                console.log(`Placed a bet of ${chipValue} using the selected chip.`);
            } else {
                console.warn(`Chip for value ${chipValue} not found!`);
            }
        });
    }

    // Betting logic
    function handleBet() {
        const balance = getBalance();
        if (balance <= 0) {
            console.warn("Insufficient balance to place a bet.");
            return;
        }

        // const betAmount = Math.floor(balance / 4); // Calculate bet amount as balance / 4
        let betAmount = Math.floor(balance / 4); // Calculate bet amount as balance / 4
        if (betAmount === 0) {
            betAmount = 1; // Set the minimum bet amount to 1 if the calculated amount is 0
        }
        console.log(`Balance: $${balance}, Bet Amount: ${betAmount}`);

        const betChunks = splitBetAmount(betAmount); // Split the bet into chunks
        console.log("Bet chunks:", betChunks);

        const choices = ["Player", "Banker"];
        const initialChoice = choices[Math.floor(Math.random() * choices.length)];
        const betChoice = initialChoice === "Player" ? "Banker" : "Player";

        console.log(`Chosen side: ${betChoice}`);

        setTimeout(() => {
            const targetButton = betChoice === "Player" ? getPlayerButton() : getBankerButton();
            placeBet(betChunks, targetButton); // Place the bet in chunks
        }, 3000); // 3000 milliseconds = 3 seconds delay
    }

    // Listen for the ResultDetected event
    window.addEventListener('ResultDetected', function (e) {
        const { name } = e.detail; // Retrieve the name (B, P, or T)
        console.log(`Received ResultDetected event with name: ${name}`);

        // Handle betting logic based on the result
        if (name === "B" || name === "P" || name === "T") {
            console.log("Triggering betting logic...");
            handleBet();
        } else {
            console.warn("Unrecognized result:", name);
        }
    });
})();
