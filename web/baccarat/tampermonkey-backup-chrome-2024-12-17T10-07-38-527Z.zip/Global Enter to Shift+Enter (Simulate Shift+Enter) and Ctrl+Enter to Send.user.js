// ==UserScript==
// @name         Global Enter to Shift+Enter (Simulate Shift+Enter) and Ctrl+Enter to Send
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Makes Enter behave like Shift+Enter globally (inserts <br>), Ctrl+Enter sends the message.
// @author       You
// @match        https://*.rawchat.top/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    console.log("Global Enter-to-Shift+Enter Script Initialized.");

    // Add a global keydown event listener
    document.addEventListener("keydown", function (event) {
        const activeElement = document.activeElement;

        // Check if the active element is content editable or a textarea
        if (activeElement.isContentEditable || activeElement.tagName === "TEXTAREA") {

            // CTRL+Enter logic (send button click)
            if (event.key === 'Enter' && event.ctrlKey) {
                event.preventDefault(); // Prevent default behavior

                // Find and click the "send" button
                const sendButton = document.querySelector('button[data-testid="send-button"]');
                if (sendButton) {
                    sendButton.click();
                } else {
                    console.error('Send button not found.');
                }
                return; // Exit to prevent further code execution
            }

            // Regular Enter logic (insert <br>)
            if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault(); // Prevent default behavior

                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    const br = document.createElement("br");

                    range.deleteContents(); // Remove selected content
                    range.insertNode(br);   // Insert a <br> element

                    // Move caret after the <br>
                    range.setStartAfter(br);
                    range.setEndAfter(br);
                    selection.removeAllRanges();
                    selection.addRange(range);
                }
            }
        }
    }, true); // Capture phase to ensure priority
})();
