// ==UserScript==
// @name         Full Page Screenshot
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Capture the entire page and download it as an image
// @author       You
// @match        https://client.pragmaticplaylive.net/desktop/blackjack2/*
// @grant        none
// @require      https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js
// ==/UserScript==

(function () {
    'use strict';

    // Function to capture the full screen
    function captureFullScreen() {
        html2canvas(document.body, { logging: true, useCORS: true }).then(canvas => {
            // Convert canvas to an image
            const imageData = canvas.toDataURL("image/png");

            // Create a download link
            const link = document.createElement("a");
            link.href = imageData;
            link.download = "full-page-screenshot.png"; // File name
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            console.log("Full page screenshot captured and downloaded.");
        }).catch(error => {
            console.error("Failed to capture the full page:", error);
        });
    }

    // Listen for the "P" key to capture the full page
    document.addEventListener("keydown", (event) => {
        if (event.key.toLowerCase() === "p") { // Press "P" to capture
            console.log("Capturing full page...");
            captureFullScreen();
        }
    });

    console.log("Press 'P' to capture the entire screen.");
})();
