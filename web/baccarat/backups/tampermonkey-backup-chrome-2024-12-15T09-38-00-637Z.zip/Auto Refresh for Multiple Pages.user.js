// ==UserScript==
// @name         Auto Refresh for Multiple Pages
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Automatically refreshes pages every 30 seconds.
// @author       Your Name
// @match        *://stake.com/casino/games/evolutionoss-baccarat-sicbo-lobby*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // Function to refresh the current page
    function refreshPage() {
        console.log("Refreshing the current page...");
        location.reload(); // Reloads the current page
    }

    // Schedule the page refresh every 30 seconds
    setInterval(refreshPage, 10000); // 30,000 milliseconds = 30 seconds
})();
