// ==UserScript==
// @name         Detect SVG + Wait for Attribute + Bet
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  Detects SVG, waits for data-is-collapsed to be false, and then bets on Player or Banker based on calculated bet amount.
// @author       Your Name
// @match        *://babylonstkn.evo-games.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isProcessing = false; // Prevent multiple simultaneous operations

    const observer = new MutationObserver((mutations) => {
        if (isProcessing) return;
        isProcessing = true;

        setTimeout(() => {
            mutations.some((mutation) => {
                if (mutation.type === "childList") {
                    return Array.from(mutation.addedNodes).some((node) => {
                        if (node.nodeName === "svg" && node.getAttribute("data-type") === "coordinates") {
                            const roadItem = node.querySelector('svg[data-type="roadItem"]');
                            if (roadItem) {
                                const name = roadItem.getAttribute("name");
                                if (name === "Banker" || name === "Player" || name === "Tie") {
                                    console.log(`Detected SVG with name: ${name}`);

                                    const balanceElement = document.querySelector('span[data-role="balance-label-value"]');
                                    if (balanceElement) {
                                        const balanceText = balanceElement.textContent.replace(/[^\d.]/g, "");
                                        const balance = parseFloat(balanceText);
                                        const betAmount = Math.max(1, Math.floor(balance / 4)); // Ensure minimum 1 bet
                                        console.log(`Balance: ${balance}, Bet Amount: ${betAmount}`);

                                        const choices = ["Player", "Banker"]; // Array of choices
                                        const betChoice = choices[Math.floor(Math.random() * choices.length)]; // Randomly choose from the array
                                        console.log(`Chosen Bet: ${betChoice}`);
                                        waitForAttributeChange(betChoice, betAmount); // Pass bet amount to the waiting function
                                    } else {
                                        console.error("Balance element not found.");
                                    }
                                    return true;
                                }
                            }
                        }
                        return false;
                    });
                }
                return false;
            });
            isProcessing = false;
        }, 100);
    });

    function waitForAttributeChange(betChoice, betAmount) {
        const targetElement = document.querySelector('[data-role="footer-perspective-container"]');
        if (!targetElement) {
            console.error("Target element for attribute change not found.");
            return;
        }

        const attributeObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === "attributes" && mutation.attributeName === "data-is-collapsed") {
                    const isCollapsed = mutation.target.getAttribute("data-is-collapsed");
                    if (isCollapsed === "false") {
                        console.log("data-is-collapsed is now false. Placing the bet.");
                        placeBet(betChoice, betAmount);
                        attributeObserver.disconnect(); // Stop observing after the bet
                    }
                }
            });
        });

        attributeObserver.observe(targetElement, {
            attributes: true
        });
    }

    function placeBet(betChoice, betAmount) {
        const betButtonSelector = betChoice === "Player" ? 'div[data-betspot-destination="Player"]' : 'div[data-betspot-destination="Banker"]';
        const betButton = document.querySelector(betButtonSelector);
        if (betButton) {
            for (let i = 0; i < betAmount; i++) { // Click the bet button according to the bet amount
                betButton.click();
                console.log(`Clicked ${betChoice} Bet ${i + 1} times.`);
            }
        } else {
            console.error(`${betChoice} Bet Button not found.`);
        }
    }

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    console.log("Monitoring for changes and betting logic is active.");
})();
