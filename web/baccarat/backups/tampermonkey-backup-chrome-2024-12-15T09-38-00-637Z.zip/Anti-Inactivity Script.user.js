// ==UserScript==
// @name         Anti-Inactivity Script
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Prevents inactivity detection on betting websites by simulating user actions.
// @author       Your Name
// @match        *://babylonstkn.evo-games.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Simulate mouse movement
    setInterval(() => {
        const event = new MouseEvent('mousemove', {
            view: window,
            bubbles: true,
            cancelable: true,
            clientX: Math.random() * window.innerWidth,
            clientY: Math.random() * window.innerHeight
        });
        document.dispatchEvent(event);
        //console.log('Simulated mouse movement');
    }, 3000); // Every 30 seconds

    // Simulate a keypress
    setInterval(() => {
        const event = new KeyboardEvent('keydown', { key: 'a', bubbles: true });
        document.dispatchEvent(event);
        //console.log('Simulated key press');
    }, 4500); // Every 45 seconds
})();
