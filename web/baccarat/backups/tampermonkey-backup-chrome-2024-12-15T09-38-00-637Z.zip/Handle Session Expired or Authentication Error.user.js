// ==UserScript==
// @name         Handle Session Expired or Authentication Error
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Automatically refresh or go back to the previous page based on session expiration or authentication failure messages.
// @author       You
// @match        https://babylonstkn.evo-games.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // Messages to detect
    const sessionExpiredText = 'Your session has expired because you were inactive for too long.';
    const authFailedText = 'User authentication failed or your session may be expired, please try again. Error Code: EV.5';
    let isHandling = false; // Prevent multiple actions

    // Function to handle actions
    function handleAction(actionType) {
        if (isHandling) return; // Avoid duplicate actions
        isHandling = true;

        if (actionType === 'refresh') {
            console.log('Session expired detected. Refreshing the page in 7 seconds...');
            setTimeout(() => {
                location.reload(); // Refresh the page
            }, 7000); // 7-second delay
        } else if (actionType === 'back') {
            console.log('Authentication failed detected. Navigating to the previous page in 7 seconds...');
            setTimeout(() => {
                history.back(); // Go back to the previous page
            }, 7000); // 7-second delay
        }
    }

    // Create a MutationObserver to monitor for changes in the DOM
    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Ensure it's an element node
                        // Check for the session expired message
                        if (node.textContent && node.textContent.includes(sessionExpiredText)) {
                            handleAction('refresh');
                        }
                        // Check for the authentication failed message
                        if (node.textContent && node.textContent.includes(authFailedText)) {
                            handleAction('back');
                        }
                    }
                });
            }
        }
    });

    // Start observing the document's body for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true // Monitor all descendants of body
    });

    // Initial check for messages on page load
    if (document.body.textContent.includes(sessionExpiredText)) {
        handleAction('refresh');
    }
    if (document.body.textContent.includes(authFailedText)) {
        handleAction('back');
    }

    console.log('MutationObserver is now running to detect session expiration or authentication failure messages...');
})();
