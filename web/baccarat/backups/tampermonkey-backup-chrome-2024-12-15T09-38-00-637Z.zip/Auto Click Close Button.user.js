// ==UserScript==
// @name         Auto Click Close Button
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically clicks the "CLOSE" button when it appears.
// @author       Your Name
// @match        *://babylonstkn.evo-games.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to observe the DOM for the button
    const observeDOM = (callback) => {
        const observer = new MutationObserver(callback);
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    };

    // Function to check and click the button
    const autoClickButton = () => {
        const button = document.querySelector('.button--673ce.sizeS--0573e.roundingBoth--6d5e6.buttonFitWidth--efe75.labelPositionInside--74c5c.buttonRoot--e868e [data-role="button-label"]');
        if (button && button.textContent.trim() === 'CLOSE') {
            console.log('CLOSE button found. Clicking...');
            button.click();
        }
    };

    // Start observing the DOM
    observeDOM(() => {
        autoClickButton();
    });
})();
