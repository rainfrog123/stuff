// ==UserScript==
// @name         Baccarat Auto-Betting System(mutiple)
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Monitors TIE results and automatically places bets on banker or player with optimized performance
// @author       Your Name
// @match        *://client.pragmaticplaylive.net/desktop/*
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @grant        GM_log
// @grant        GM_setValue
// @grant        GM_getValue
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    // ==========================================
    // CONFIGURATION SETTINGS
    // ==========================================
    const CONFIG = {
        // Betting settings
        chipValue: 0.2,                  // Value of each chip click
        minBetAmount: 0.2,               // Minimum bet amount
        maxBalancePercentage: 0.25,       // Maximum percentage of balance to bet (0.5 = 50%)
        clickDelay: 10,                  // Delay between clicks in milliseconds

        // Timing settings
        betDelayMin: 6000,               // Minimum delay before placing bet (ms)
        betDelayRandom: 3000,            // Additional random delay (ms)

        // DOM selectors
        counterSelector: '.TileStatistics_round-mobile-counter__cjd3w',
        bankerPrefix: "betPositionBGTemp mobile banker",
        playerPrefix: "betPositionBGTemp mobile player",

        // Storage keys
        balanceKey: 'currentBalance',

        // Debug settings
        debug: true                      // Enable detailed logging
    };

    // ==========================================
    // UTILITY FUNCTIONS
    // ==========================================

    /**
     * Logger utility with different log levels
     */
    const Logger = {
        info: (message) => {
            if (CONFIG.debug) console.log(`[INFO] ${message}`);
        },
        warn: (message) => console.warn(`[WARN] ${message}`),
        error: (message) => console.error(`[ERROR] ${message}`),
        bet: (table, message) => {
            if (CONFIG.debug) console.log(`[BET:${table}] ${message}`);
        }
    };

    /**
     * Generate a cryptographically secure random number between 0 and 1
     * @returns {number} Random number between 0 and 1
     */
    function secureRandom() {
        const array = new Uint32Array(1);
        window.crypto.getRandomValues(array);
        return array[0] / (0xFFFFFFFF + 1); // Normalize to range [0,1)
    }

    /**
     * Get a random delay within the configured range
     * @returns {number} Delay in milliseconds
     */
    function getRandomDelay() {
        return CONFIG.betDelayMin + (secureRandom() * CONFIG.betDelayRandom);
    }

    // ==========================================
    // BALANCE MANAGEMENT
    // ==========================================

    /**
     * Retrieve balance from localStorage
     * @returns {number} Current balance
     */
    function getBalance() {
        try {
            const balance = parseFloat(localStorage.getItem(CONFIG.balanceKey));
            const timestamp = localStorage.getItem(`${CONFIG.balanceKey}_timestamp`);

            // Check if balance exists and is not too old (30 seconds max)
            const isBalanceValid = !isNaN(balance) && balance > 0;
            const isBalanceFresh = timestamp && (Date.now() - parseInt(timestamp) < 30000);

            if (isBalanceValid) {
                if (isBalanceFresh) {
                    Logger.info(`Retrieved Balance: ${balance.toFixed(2)}`);
                } else {
                    Logger.warn(`Using potentially stale balance: ${balance.toFixed(2)}`);
                }
                return balance;
            } else {
                Logger.warn('No valid balance found in localStorage. Defaulting to 0.');
                return 0;
            }
        } catch (error) {
            Logger.error(`Error retrieving balance: ${error.message}`);
            return 0;
        }
    }

    /**
     * Calculate bet amount based on current balance
     * @returns {number} Calculated bet amount
     */
    function calculateBetAmount() {
        const balance = getBalance();
        if (balance <= 0) return 0;

        const maxBetAmount = balance * CONFIG.maxBalancePercentage;
        const randomValue = secureRandom();
        let betAmount = Math.round((randomValue * maxBetAmount) * 100) / 100;

        // Ensure minimum bet
        return Math.max(betAmount, CONFIG.minBetAmount);
    }

    // ==========================================
    // BETTING FUNCTIONS
    // ==========================================

    /**
     * Simulate multiple clicks for a total bet amount
     * @param {Element} button - Button element to click
     * @param {number} totalAmount - Total amount to bet
     */
    function simulateBetClicks(button, totalAmount) {
        if (!button || totalAmount <= 0) return;

        const clicks = Math.floor(totalAmount / CONFIG.chipValue);

        for (let i = 0; i < clicks; i++) {
            setTimeout(() => {
                try {
                    button.click();
                    Logger.info(`Clicked ${i + 1}/${clicks} for bet amount: ${totalAmount}`);
                } catch (error) {
                    Logger.error(`Error clicking button: ${error.message}`);
                }
            }, i * CONFIG.clickDelay);
        }
    }

    /**
     * Place a bet on a randomly chosen side
     * @param {string} tableId - Table identifier for logging
     * @param {Element} bankerButton - Banker button element
     * @param {Element} playerButton - Player button element
     */
    function placeBet(tableId, bankerButton, playerButton) {
        const betAmount = calculateBetAmount();
        if (betAmount <= 0) {
            Logger.warn(`${tableId}: Insufficient balance to place a bet.`);
            return;
        }

        // Randomly choose between player or banker
        const randomChoice = secureRandom() < 0.5 ? "banker" : "player";
        const targetButton = randomChoice === "banker" ? bankerButton : playerButton;

        if (!targetButton) {
            Logger.warn(`${tableId}: No valid button found for ${randomChoice}.`);
            return;
        }

        Logger.bet(tableId, `Betting ${betAmount} on ${randomChoice.toUpperCase()}`);

        // Add random delay before placing bet
        const delay = getRandomDelay();
        setTimeout(() => {
            simulateBetClicks(targetButton, betAmount);
        }, delay);
    }

    // ==========================================
    // DOM MONITORING
    // ==========================================

    /**
     * Find betting buttons in the parent element
     * @param {Element} parentElement - Parent element containing buttons
     * @returns {Object} Object containing banker and player buttons
     */
    function findBettingButtons(parentElement) {
        if (!parentElement) return { bankerButton: null, playerButton: null };

        // Cache all elements to avoid multiple DOM queries
        const elements = Array.from(parentElement.querySelectorAll("*"));

        const bankerButton = elements.find(el => el.className &&
                                          el.className.includes(CONFIG.bankerPrefix));
        const playerButton = elements.find(el => el.className &&
                                          el.className.includes(CONFIG.playerPrefix));

        return { bankerButton, playerButton };
    }

    /**
     * Extract table identifier from parent element
     * @param {Element} parentElement - Parent element
     * @returns {string} Table identifier
     */
    function getTableIdentifier(parentElement) {
        try {
            const fullText = parentElement.textContent || '';
            return fullText.split('$')[0].trim() || 'Unknown Table';
        } catch (error) {
            return 'Unknown Table';
        }
    }

    /**
     * Setup observer for TIE counter changes
     * @param {Element} counter - Counter element
     */
    function setupTieCounterObserver(counter) {
        if (!counter) return;

        try {
            const parentElement = counter.parentElement?.parentElement?.parentElement?.parentElement?.parentElement;
            if (!parentElement) {
                Logger.warn('Could not find parent element for counter');
                return;
            }

            const tableId = getTableIdentifier(parentElement);
            Logger.info(`Setting up observer for table: ${tableId}`);

            // Find the TIE counter element
            const tieCounter = counter.nextElementSibling?.nextElementSibling?.nextElementSibling;
            if (!tieCounter) {
                Logger.warn(`${tableId}: Could not find TIE counter element`);
                return;
            }

            // Cache the betting buttons to avoid repeated DOM queries
            const { bankerButton, playerButton } = findBettingButtons(parentElement);
            if (!bankerButton && !playerButton) {
                Logger.warn(`${tableId}: No valid betting buttons found`);
                return;
            }

            // Create and setup the observer
            const observer = new MutationObserver((mutations) => {
                for (const mutation of mutations) {
                    if (mutation.type !== 'childList' && mutation.type !== 'characterData') continue;

                    const newValueMatch = tieCounter.textContent.match(/\d+/);
                    if (!newValueMatch) continue;

                    const newValue = newValueMatch[0];
                    Logger.bet(tableId, `TIE counter changed to: ${newValue}`);

                    // Place bet when TIE counter changes
                    placeBet(tableId, bankerButton, playerButton);
                    break; // Process only once per batch of mutations
                }
            });

            // Start observing
            observer.observe(tieCounter, {
                childList: true,
                characterData: true,
                subtree: true,
            });

            Logger.bet(tableId, 'Monitoring for TIE counter changes...');
        } catch (error) {
            Logger.error(`Error setting up observer: ${error.message}`);
        }
    }

    /**
     * Initialize the monitoring system
     */
    function initialize() {
        Logger.info('Initializing Baccarat Auto-Betting System...');

        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', startMonitoring);
        } else {
            startMonitoring();
        }
    }

    /**
     * Start monitoring for TIE counters
     */
    function startMonitoring() {
        try {
            const counters = document.querySelectorAll(CONFIG.counterSelector);

            if (!counters || counters.length === 0) {
                Logger.warn('No counters found. Will retry in 5 seconds...');
                setTimeout(startMonitoring, 5000);
                return;
            }

            Logger.info(`Found ${counters.length} table counters`);

            // Setup observers for each counter
            counters.forEach(setupTieCounterObserver);

            Logger.info('Monitoring system started successfully');
        } catch (error) {
            Logger.error(`Error starting monitoring: ${error.message}`);
            // Retry after delay
            setTimeout(startMonitoring, 5000);
        }
    }

    // ==========================================
    // INITIALIZATION
    // ==========================================
    initialize();
})();
