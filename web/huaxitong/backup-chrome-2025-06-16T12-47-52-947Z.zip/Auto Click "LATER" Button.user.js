// ==UserScript==
// @name         Auto Click "LATER" Button
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically clicks the "LATER" button on the Pragmatic Play Live Blackjack page.
// @author       You
// @match        https://client.pragmaticplaylive.net/desktop/blackjack2/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to detect and click the button
    function clickLaterButton() {
        const button = document.querySelector('button.pp_desktopBTN2#alertBTN2');
        if (button) {
            button.click();
            console.log('"LATER" button clicked!');
        }
    }

    // Observe the DOM for changes and look for the button
    const observer = new MutationObserver(() => {
        clickLaterButton();
    });

    // Start observing the body for added nodes
    observer.observe(document.body, { childList: true, subtree: true });

    // Initial check in case the button is already present
    clickLaterButton();
})();
