// ==UserScript==
// @name         Stake Casino Bet Time Checker with Notification
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Auto-refresh, check bet time difference, and send notification if > 5 minutes
// @author       You
// @match        *://stake.com/casino/my-bets*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to send a notification
    function sendNotification(title, body) {
        if (Notification.permission === "granted") {
            new Notification(title, {
                body: body,
                icon: "https://via.placeholder.com/128" // Optional: Replace with any icon URL
            });
        } else {
            console.warn("Notification permission is not granted!");
        }
    }

    // Function to check the time difference and send a warning
    function checkBetTimeDifference() {
        console.clear(); // Clear console to keep it clean

        // Select the row with data-bet-index="0"
        const row = document.querySelector('tr[data-bet-index="0"]');
        if (!row) {
            console.log("❌ No matching bet row found!");
            return;
        }

        // Extract the 3rd <td> (time cell)
        const timeCell = row.querySelectorAll('td')[2];
        const timeText = timeCell.textContent.trim(); // e.g., "11:33 PM 12/17/2024"

        console.log("⏱ Extracted Time:", timeText);

        // Add explicit UTC+00:00 to ensure correct time parsing
        const timeWithZone = timeText + " UTC+00:00";

        // Parse the extracted time into a Date object
        const extractedTime = new Date(timeWithZone);

        // Get the current time
        const currentTime = new Date();
        console.log("⏰ Current Time:", currentTime);

        // Check if the extracted time is valid
        if (isNaN(extractedTime.getTime())) {
            console.error("⚠ Invalid extracted time format:", timeText);
            return;
        }

        // Calculate the time difference in milliseconds
        const timeDifferenceMs = currentTime - extractedTime;

        // Convert the difference to minutes
        const timeDifferenceMinutes = timeDifferenceMs / (1000 * 60);
        console.log(`🕒 Time Difference: ${timeDifferenceMinutes.toFixed(2)} minutes`);

        // Check if the difference is greater than 5 minutes
        if (timeDifferenceMinutes > 5) {
            console.warn("⚠ WARNING: The time difference is greater than 5 minutes!");

            // Send a Chrome notification
            sendNotification("Time Alert 🚨", "The time difference exceeds 5 minutes!");
        } else {
            console.log("✅ Time difference is within 5 minutes.");
        }
    }

    // Function to auto-refresh the page every 2 minutes
    function autoRefresh() {
        console.log("🔄 Auto-refreshing the page in 2 minutes...");
        setTimeout(() => {
            location.reload();
        }, 120000); // 2 minutes = 120000 milliseconds
    }

    // Request Notification Permission
    if ("Notification" in window) {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                console.log("✅ Notification permission granted!");
            } else {
                console.warn("⚠ Notification permission denied!");
            }
        });
    } else {
        console.log("❌ Notifications are not supported in this browser.");
    }

    // Run the script
    console.log("🏁 Stake Casino Bet Time Checker Started");
    checkBetTimeDifference(); // Perform the time check initially
    autoRefresh(); // Schedule auto-refresh
})();
